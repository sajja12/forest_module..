package com.cg.fms.dao;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.cg.fms.dto.Product;
import com.cg.fms.exceptions.FmsException;
import com.cg.fms.service.ProductService;
import com.cg.fms.utility.Connection;


public class ProductDao implements IProductDao {

	EntityManagerFactory factory=null;
	EntityManager manager=null;
	EntityTransaction transaction=null;
	
	@Override
	public Product addProduct(Product product) 
	{
		factory = Connection.getFactory();
		manager = factory.createEntityManager();
		transaction = manager.getTransaction();
		transaction.begin();
		manager.persist(product);
		transaction.commit();
		return product;
	}

	public Product getProduct(String productId) 
	{
		factory = Connection.getFactory();
		manager = factory.createEntityManager();
		Product product = manager.find(Product.class, productId);
		if (product == null) {
			throw new FmsException("product not found with the given id");
		}
		return product;
		
	}

	@Override
	public boolean UpdateProduct(Product product) {
		return false;
	}

	@Override
	public boolean deleteProduct(String productId) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<Product> getAllProduct() {
		factory = Connection.getFactory();
		manager = factory.createEntityManager();
		String selectQuery ="Select e from product e where productId='1' ";
		Query query=manager.createQuery(selectQuery);
		List<Product> list=query.getResultList();
		System.out.println(list);
		return list;
	}

	
}
