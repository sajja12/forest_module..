package com.cg.fms.ui;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.cg.fms.dto.Product;
import com.cg.fms.exceptions.FmsException;
import com.cg.fms.service.IProductService;
import com.cg.fms.service.ProductService;

public class ProductMain 
{
	IProductService service=new ProductService();
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		IProductService service=new ProductService();
		while(true)
		{
			System.out.println("Select your choice");
			System.out.println("1.Add Products");
			System.out.println("2.Get Products");
			System.out.println("3.Update Products");
			System.out.println("4.Delete Products");
			System.out.println("5.Get all the products");
			int ch=sc.nextInt();
			switch(ch)
			{
				case 1:
				{
					System.out.println("enter the productId");
					String productId=sc.next();
					System.out.println("enter the product name ");
					String productName=sc.next();
					System.out.println("enter the product Quantity");
					String productQuantity=sc.next();
					System.out.println("enter the product Description");
					String productDescription=sc.next();
					Product p= new Product(productId, productName, productQuantity, productDescription);
					service.addProduct(p);
					System.out.println("Product added successfully");
				}				
				break;
				case 2:
				{
					System.out.println("enter the product you want to get ");
					String productId=sc.next();
					try {
						Product product=service.getProduct(productId);
						System.out.println("Product details are: ");
					}
					catch(FmsException e) {
						System.out.println(e.getMessage());
					}
				} 
				break;
//				case 5:
//				{
//					try
//					{
//						List<Product> list=new ArrayList<Product>();
//						list=service.getAllProduct();
//					}
//					catch(FmsException e) {
//						System.out.println(e.getMessage());
//					}
//				}
				default : System.out.println("closing the product table");
			}
			
		}
	}
}
