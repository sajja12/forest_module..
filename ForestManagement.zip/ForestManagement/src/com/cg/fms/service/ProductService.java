package com.cg.fms.service;

import java.util.List;

import com.cg.fms.dao.IProductDao;
import com.cg.fms.dao.ProductDao;
import com.cg.fms.dto.Product;

public class ProductService implements IProductService{
	IProductDao dao=new ProductDao();
	
	public Product addProduct(Product product) {
		// TODO Auto-generated method stub
		return dao.addProduct(product);
	}

	@Override
	public Product getProduct(String productId) {
		return dao.getProduct(productId);

	}

	@Override
	public Product UpdateProduct(Product product) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public com.cg.fms.dto.Product deleteProduct(String productId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Product> getAllProduct() {
		return dao.getAllProduct();
	}

	
}

