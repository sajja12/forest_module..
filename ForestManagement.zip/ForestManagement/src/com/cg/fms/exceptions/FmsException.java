package com.cg.fms.exceptions;

public class FmsException extends RuntimeException{
	public FmsException(String message)
	{
		super(message);
	}
}
