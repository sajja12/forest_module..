package com.cg.fms.service;

import java.util.List;

import com.cg.fms.dao.IProductDao;
import com.cg.fms.dao.ProductDao;
import com.cg.fms.dto.Product;

public class ProductService implements IProductService{
	IProductDao dao=new ProductDao();
	
	public boolean addProduct(Product product) {
		// TODO Auto-generated method stub
		if(dao.addProduct(product)) {
			return true;
		}
		else {
			return false;
		}
	}

	@Override
	public Product getProduct(String productId) {
		return dao.getProduct(productId);

	}

	@Override
	public boolean UpdateProduct(Product product) {
		if(dao.UpdateProduct(product)) {
			return true;
		}
		else {
			return false;
		}
	}

	@Override
	public boolean deleteProduct(String productId) {
		if(dao.deleteProduct(productId)) {
			return true;
		}
		else {
			return false;
		}
	}

	@Override
	public List<Product> getAllProduct() {
		return dao.getAllProduct();
	}

	
}

